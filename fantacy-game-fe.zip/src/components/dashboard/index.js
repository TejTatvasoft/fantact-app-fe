import React from 'react';
import './style.css';

export default function Dashboard() {

    return(
        <div>Dashboard</div>
    );
}