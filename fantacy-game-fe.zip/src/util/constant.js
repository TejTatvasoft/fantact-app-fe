const routes = {
  dashboard: "/dashboard",
  login: "/",
  logout: "/logout",
};
export {
  routes
};