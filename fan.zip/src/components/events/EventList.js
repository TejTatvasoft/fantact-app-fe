import React from "react";

import Movie from "./Event";
import classes from "./EventList.module.css";

const EventList = (props) => {

  console.log(props.events);

  return (
    <ul className={classes["movies-list"]}>
      {props.events.map((event) => (
        <Movie
          key={event.episode_id}
          title={event.title}
          releaseDate={event.release_date}
          openingText={event.opening_crawl}
        />
      ))}
    </ul>
  );
};

export default EventList;
